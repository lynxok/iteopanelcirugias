import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

type AlertSeverity = 'Critical' | 'Urgent' | 'Warning' | 'Info';
type AlertStatus = 'Active' | 'Resolved';
type TargetRole = 'Ortopedia' | 'Internacion' | 'SuperAdmin';

interface SystemAlert {
  id: string;
  type: string; // e.g. "Gestión Prótesis", "Pre-Qx"
  severity: AlertSeverity;
  title: string;
  message: string;
  patientName: string;
  surgeryId: string;
  targetRole: TargetRole;
  dateGenerated: string;
  deadlineDate: string; // The date of surgery or expiration
  status: AlertStatus;
  resolvedAt?: string;
  resolvedBy?: string;
}

const MOCK_ALERTS: SystemAlert[] = [
    // --- ORTOPEDIA ALERTS (Based on the 14-21 day rule) ---
    {
        id: 'alt-001',
        type: 'Gestión Prótesis',
        severity: 'Critical',
        title: 'Plazo Vencido (<14 días)',
        message: 'Cirugía programada en 10 días requiere prótesis y no hay confirmación de material.',
        patientName: 'Gomez, Roberto',
        surgeryId: '108',
        targetRole: 'Ortopedia',
        dateGenerated: 'Hoy, 08:00 AM',
        deadlineDate: '2023-11-05',
        status: 'Active'
    },
    {
        id: 'alt-002',
        type: 'Gestión Prótesis',
        severity: 'Warning',
        title: 'Planificación Anticipada',
        message: 'Faltan 18 días para la cirugía. Inicie gestión de importación de Clavos Intramedulares.',
        patientName: 'Diaz, Carlos',
        surgeryId: '109',
        targetRole: 'Ortopedia',
        dateGenerated: 'Ayer, 09:30 AM',
        deadlineDate: '2023-11-14',
        status: 'Active'
    },
    {
        id: 'alt-003',
        type: 'Gestión Prótesis',
        severity: 'Urgent',
        title: 'Material Rechazado',
        message: 'Auditoría rechazó la marca de la prótesis de cadera. Requiere cambio inmediato.',
        patientName: 'Lopez, Maria',
        surgeryId: '101',
        targetRole: 'Ortopedia',
        dateGenerated: '2023-10-23',
        deadlineDate: '2023-10-30',
        status: 'Resolved',
        resolvedAt: '2023-10-24 14:00',
        resolvedBy: 'Juan Ortopedia'
    },

    // --- INTERNACION ALERTS (Based on the 7 day rule) ---
    {
        id: 'alt-004',
        type: 'Estudios Pre-Qx',
        severity: 'Critical',
        title: 'Riesgo de Cancelación',
        message: 'Faltan 3 días para cirugía y no se han cargado estudios de cardiología.',
        patientName: 'Perez, Juan',
        surgeryId: '105',
        targetRole: 'Internacion',
        dateGenerated: 'Hoy, 07:00 AM',
        deadlineDate: '2023-10-28',
        status: 'Active'
    },
    {
        id: 'alt-005',
        type: 'Estudios Pre-Qx',
        severity: 'Urgent',
        title: 'Falta Consentimiento',
        message: 'Paciente programado para la próxima semana sin firma de consentimiento informado.',
        patientName: 'Vazquez, Elena',
        surgeryId: '106',
        targetRole: 'Internacion',
        dateGenerated: '2023-10-22',
        deadlineDate: '2023-11-01',
        status: 'Resolved',
        resolvedAt: '2023-10-23 10:00',
        resolvedBy: 'Lic. Ana Torres'
    }
];

const AlertsHistory: React.FC = () => {
  const navigate = useNavigate();
  
  // State for Simulation
  const [currentUserRole, setCurrentUserRole] = useState<TargetRole>('Ortopedia');
  const [alerts, setAlerts] = useState<SystemAlert[]>(MOCK_ALERTS);
  const [filterStatus, setFilterStatus] = useState<'All' | 'Active' | 'Resolved'>('Active');

  // Filter Logic
  const filteredAlerts = alerts.filter(alert => {
      const roleMatch = currentUserRole === 'SuperAdmin' || alert.targetRole === currentUserRole;
      const statusMatch = filterStatus === 'All' || alert.status === filterStatus;
      return roleMatch && statusMatch;
  });

  const handleResolve = (id: string) => {
      const now = new Date().toLocaleString();
      setAlerts(prev => prev.map(a => 
          a.id === id 
            ? { ...a, status: 'Resolved', resolvedAt: now, resolvedBy: 'Usuario Actual' } 
            : a
      ));
  };

  // Helper for Styles
  const getSeverityStyles = (severity: AlertSeverity) => {
      switch (severity) {
          case 'Critical': return { bg: 'bg-slate-900', border: 'border-red-500', text: 'text-red-400', icon: 'gpp_maybe' };
          case 'Urgent': return { bg: 'bg-red-50', border: 'border-red-200', text: 'text-red-700', icon: 'error' };
          case 'Warning': return { bg: 'bg-amber-50', border: 'border-amber-200', text: 'text-amber-700', icon: 'warning' };
          case 'Info': return { bg: 'bg-blue-50', border: 'border-blue-200', text: 'text-blue-700', icon: 'info' };
      }
  };

  return (
    <div className="flex-1 h-full overflow-y-auto bg-slate-50 p-8 font-sans">
        
        {/* DEV TOOL: Role Switcher */}
        <div className="fixed bottom-4 right-4 z-50 bg-slate-800 text-white p-2 rounded-lg shadow-lg opacity-90 hover:opacity-100 transition-opacity flex items-center gap-2 text-xs border border-slate-600">
            <span className="font-bold text-amber-400">Ver historial como:</span>
            <select 
                value={currentUserRole} 
                onChange={(e) => setCurrentUserRole(e.target.value as TargetRole)}
                className="bg-slate-700 border-none rounded text-xs py-1 focus:ring-1 focus:ring-amber-400 cursor-pointer outline-none"
            >
                <option value="SuperAdmin">SuperAdmin (Ver Todo)</option>
                <option value="Ortopedia">Ortopedia</option>
                <option value="Internacion">Internación</option>
            </select>
        </div>

        <div className="max-w-5xl mx-auto flex flex-col gap-6">
            
            {/* Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                        <span className="material-symbols-outlined text-red-500">notifications_active</span>
                        Centro de Alertas
                    </h1>
                    <p className="text-slate-500 text-sm mt-1">
                        Gestión de incidencias y avisos automáticos para el rol: <strong className="text-slate-700">{currentUserRole}</strong>
                    </p>
                </div>

                {/* Status Tabs */}
                <div className="bg-white border border-slate-200 p-1 rounded-lg flex shadow-sm">
                    {['Active', 'Resolved', 'All'].map(status => (
                        <button
                            key={status}
                            onClick={() => setFilterStatus(status as any)}
                            className={`px-4 py-1.5 rounded-md text-xs font-bold transition-all ${
                                filterStatus === status 
                                ? 'bg-slate-800 text-white shadow-sm' 
                                : 'text-slate-500 hover:text-slate-900 hover:bg-slate-50'
                            }`}
                        >
                            {status === 'Active' ? 'Pendientes' : status === 'Resolved' ? 'Resueltas' : 'Historial Completo'}
                        </button>
                    ))}
                </div>
            </div>

            {/* ALERTS LIST */}
            <div className="flex flex-col gap-4">
                {filteredAlerts.length > 0 ? (
                    filteredAlerts.map(alert => {
                        const styles = getSeverityStyles(alert.severity);
                        const isResolved = alert.status === 'Resolved';

                        return (
                            <div 
                                key={alert.id} 
                                className={`relative flex flex-col md:flex-row gap-4 p-5 rounded-xl border shadow-sm transition-all ${
                                    isResolved ? 'bg-white border-slate-200 opacity-70 grayscale-[0.5]' : `bg-white ${styles.border} border-l-4`
                                }`}
                            >
                                {/* Left Icon */}
                                <div className="flex-shrink-0">
                                    <div className={`size-10 rounded-full flex items-center justify-center ${
                                        isResolved ? 'bg-slate-100 text-slate-400' : `${styles.bg} ${styles.text}`
                                    }`}>
                                        <span className="material-symbols-outlined">{isResolved ? 'check' : styles.icon}</span>
                                    </div>
                                </div>

                                {/* Content */}
                                <div className="flex-1">
                                    <div className="flex flex-wrap justify-between items-start mb-1">
                                        <div className="flex items-center gap-2">
                                            <span className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                                                isResolved ? 'bg-slate-100 text-slate-500' : `${styles.bg} ${styles.text}`
                                            }`}>
                                                {alert.type}
                                            </span>
                                            <h3 className={`font-bold text-base ${isResolved ? 'text-slate-600 line-through' : 'text-slate-900'}`}>
                                                {alert.title}
                                            </h3>
                                        </div>
                                        <span className="text-xs text-slate-400 font-medium">Generado: {alert.dateGenerated}</span>
                                    </div>

                                    <p className={`text-sm mb-3 ${isResolved ? 'text-slate-500' : 'text-slate-700'}`}>
                                        {alert.message}
                                    </p>

                                    {/* Footer Details */}
                                    <div className="flex flex-wrap items-center gap-4 text-xs bg-slate-50 p-2 rounded-lg border border-slate-100 w-fit">
                                        <div className="flex items-center gap-1.5 text-slate-600">
                                            <span className="material-symbols-outlined text-sm">person</span>
                                            <span className="font-bold">{alert.patientName}</span>
                                        </div>
                                        <div className="w-px h-3 bg-slate-300"></div>
                                        <div className="flex items-center gap-1.5 text-slate-600">
                                            <span className="material-symbols-outlined text-sm">assignment</span>
                                            <span>Cirugía #{alert.surgeryId}</span>
                                        </div>
                                        <div className="w-px h-3 bg-slate-300"></div>
                                        <div className="flex items-center gap-1.5 text-slate-600">
                                            <span className="material-symbols-outlined text-sm">event_busy</span>
                                            <span>Límite: <span className="font-mono font-bold text-slate-800">{alert.deadlineDate}</span></span>
                                        </div>
                                    </div>

                                    {/* Resolution Info */}
                                    {isResolved && (
                                        <div className="mt-3 text-xs text-emerald-600 font-bold flex items-center gap-1">
                                            <span className="material-symbols-outlined text-sm">task_alt</span>
                                            Resuelto por {alert.resolvedBy} el {alert.resolvedAt}
                                        </div>
                                    )}
                                </div>

                                {/* Actions */}
                                {!isResolved && (
                                    <div className="flex flex-row md:flex-col gap-2 justify-center border-t md:border-t-0 md:border-l border-slate-100 pt-4 md:pt-0 md:pl-4 min-w-[140px]">
                                        <button 
                                            onClick={() => navigate(`/detail/${alert.surgeryId}`)}
                                            className="flex-1 px-3 py-2 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-2"
                                        >
                                            Ver Cirugía
                                        </button>
                                        <button 
                                            onClick={() => handleResolve(alert.id)}
                                            className="flex-1 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg transition-colors shadow-sm flex items-center justify-center gap-2"
                                        >
                                            <span className="material-symbols-outlined text-sm">check</span>
                                            Resolver
                                        </button>
                                    </div>
                                )}
                            </div>
                        );
                    })
                ) : (
                    <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-300">
                        <span className="material-symbols-outlined text-4xl text-slate-300 mb-2">check_circle</span>
                        <h3 className="text-slate-900 font-bold">Todo al día</h3>
                        <p className="text-slate-500 text-sm">No hay alertas {filterStatus === 'Active' ? 'activas' : ''} para {currentUserRole} en este momento.</p>
                    </div>
                )}
            </div>
        </div>
    </div>
  );
};

export default AlertsHistory;