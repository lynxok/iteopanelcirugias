import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

// --- Types ---
interface PreOpPatient {
  id: string;
  name: string;
  age: number;
  doctor: string;
  proc: string;
  priority: 'Normal' | 'Urgente' | 'Alta';
  
  // Status Flags
  materialStatus: 'OK' | 'Pending' | 'Missing';
  clinicalStatus: 'OK' | 'Pending' | 'Missing';
  adminStatus: 'OK' | 'Pending';
  
  // Metadata
  dateAdded: string;
  lastUpdate: string;
  tags?: string[];
}

// --- Initial Data ---
const INITIAL_DATA: PreOpPatient[] = [
  // READY TO SCHEDULE
  { id: '11.223.344', name: 'Carlos Ruiz', age: 29, doctor: 'Dr. Garcia', proc: 'Apendicectomía', priority: 'Alta', materialStatus: 'OK', clinicalStatus: 'OK', adminStatus: 'OK', dateAdded: '2023-10-20', lastUpdate: 'Hoy' },
  { id: '99.888.777', name: 'Elena Vazquez', age: 41, doctor: 'Dra. Lopez', proc: 'Reparación LCA', priority: 'Normal', materialStatus: 'OK', clinicalStatus: 'OK', adminStatus: 'OK', dateAdded: '2023-10-18', lastUpdate: 'Ayer' },
  
  // BLOCKED BY MATERIALS
  { id: '67.890.123', name: 'Maria Rodriguez', age: 52, doctor: 'Dra. Lopez', proc: 'Reemplazo Cadera', priority: 'Urgente', materialStatus: 'Missing', clinicalStatus: 'OK', adminStatus: 'OK', dateAdded: '2023-10-15', lastUpdate: 'Hace 2h', tags: ['Cotización'] },
  { id: '99.111.222', name: 'Pedro Alcazar', age: 45, doctor: 'Dr. Smith', proc: 'Osteosíntesis Fémur', priority: 'Normal', materialStatus: 'Pending', clinicalStatus: 'OK', adminStatus: 'OK', dateAdded: '2023-10-21', lastUpdate: 'Ayer' },

  // BLOCKED BY CLINICAL
  { id: '44.555.666', name: 'Jorge Ramirez', age: 71, doctor: 'Dr. Garcia', proc: 'Eval Cardio', priority: 'Alta', materialStatus: 'OK', clinicalStatus: 'Missing', adminStatus: 'OK', dateAdded: '2023-10-22', lastUpdate: 'Hoy', tags: ['ECG'] },
  
  // MIXED / NEW
  { id: '12.345.678', name: 'Jose Perez', age: 34, doctor: 'Dr. Garcia', proc: 'Hernioplastia', priority: 'Normal', materialStatus: 'Pending', clinicalStatus: 'Pending', adminStatus: 'Pending', dateAdded: '2023-10-23', lastUpdate: 'Reciente' },
];

// --- Helpers ---
const calculateProgress = (p: PreOpPatient) => {
    let score = 0;
    if (p.materialStatus === 'OK') score += 33;
    if (p.clinicalStatus === 'OK') score += 33;
    if (p.adminStatus === 'OK') score += 34;
    return score;
};

const isReady = (p: PreOpPatient) => p.materialStatus === 'OK' && p.clinicalStatus === 'OK' && p.adminStatus === 'OK';

// --- Components ---
const StatusBadge = ({ type, status }: { type: 'Mat' | 'Clin' | 'Adm', status: string }) => {
    let colorClass = 'bg-slate-100 text-slate-500';
    let icon = 'remove';

    if (status === 'OK') { colorClass = 'bg-emerald-100 text-emerald-700 border-emerald-200'; icon = 'check'; }
    if (status === 'Pending') { colorClass = 'bg-amber-100 text-amber-700 border-amber-200'; icon = 'hourglass_empty'; }
    if (status === 'Missing') { colorClass = 'bg-red-100 text-red-700 border-red-200'; icon = 'close'; }

    return (
        <div className={`flex items-center gap-1.5 px-2 py-1 rounded border text-[10px] font-bold uppercase tracking-wide ${colorClass}`}>
            <span className="material-symbols-outlined text-xs font-bold">{icon}</span>
            <span>{type}</span>
        </div>
    );
};

const PatientCard: React.FC<{ patient: PreOpPatient; minimal?: boolean }> = ({ patient, minimal = false }) => {
    const navigate = useNavigate();
    const progress = calculateProgress(patient);
    
    return (
      <div 
          onClick={() => navigate(`/detail/${patient.id}`)}
          className="group bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md hover:border-primary/30 transition-all p-4 cursor-pointer relative overflow-hidden"
      >
          {/* Left accent border based on priority */}
          <div className={`absolute left-0 top-0 bottom-0 w-1 ${patient.priority === 'Urgente' || patient.priority === 'Alta' ? 'bg-red-500' : 'bg-blue-500'}`}></div>

          <div className="flex justify-between items-start mb-2 pl-3">
              <div>
                  <h4 className="font-bold text-slate-900 group-hover:text-primary transition-colors">{patient.name}</h4>
                  <p className="text-xs text-slate-500 flex items-center gap-1">
                      <span className="font-mono">{patient.id}</span>
                      <span>•</span>
                      <span>{patient.age} años</span>
                  </p>
              </div>
              {patient.priority !== 'Normal' && (
                   <span className="bg-red-50 text-red-600 text-[10px] font-bold px-2 py-0.5 rounded uppercase">
                      {patient.priority}
                  </span>
              )}
          </div>

          <div className="pl-3 grid grid-cols-2 gap-y-2 gap-x-4 mb-4">
               <div className="text-xs text-slate-600 flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-sm text-slate-400">person</span>
                  <span className="truncate">{patient.doctor}</span>
               </div>
               <div className="text-xs text-slate-600 flex items-center gap-1.5">
                  <span className="material-symbols-outlined text-sm text-slate-400">medical_information</span>
                  <span className="truncate">{patient.proc}</span>
               </div>
          </div>

          {/* Status Indicators Row */}
          {!minimal && (
              <div className="pl-3 flex items-center gap-2 mb-3">
                  <StatusBadge type="Mat" status={patient.materialStatus} />
                  <StatusBadge type="Clin" status={patient.clinicalStatus} />
                  <StatusBadge type="Adm" status={patient.adminStatus} />
              </div>
          )}

          {/* Progress Bar */}
          <div className="pl-3">
               <div className="flex justify-between text-[10px] text-slate-400 mb-1 font-medium">
                  <span>Prep. Pre-Qx</span>
                  <span>{progress}%</span>
               </div>
               <div className="w-full bg-slate-100 rounded-full h-1.5">
                  <div 
                      className={`h-1.5 rounded-full transition-all duration-500 ${progress === 100 ? 'bg-emerald-500' : 'bg-blue-500'}`} 
                      style={{width: `${progress}%`}}
                  ></div>
               </div>
          </div>

          {/* Hover Action */}
          <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
              <button className="text-slate-400 hover:text-primary">
                  <span className="material-symbols-outlined text-xl">open_in_new</span>
              </button>
          </div>
      </div>
    );
};

const Kanban: React.FC = () => {
  const navigate = useNavigate();
  const [patients, setPatients] = useState<PreOpPatient[]>(INITIAL_DATA);
  const [filterText, setFilterText] = useState('');

  // Grouping Data
  const readyPatients = patients.filter(p => isReady(p));
  const materialBlockers = patients.filter(p => !isReady(p) && p.materialStatus !== 'OK');
  const clinicalBlockers = patients.filter(p => !isReady(p) && p.clinicalStatus !== 'OK' && p.materialStatus === 'OK'); // Only clinical missing, materials fine
  const newRequests = patients.filter(p => !isReady(p) && p.materialStatus === 'Pending' && p.clinicalStatus === 'Pending');

  return (
    <div className="flex-1 h-full overflow-y-auto bg-slate-50 flex flex-col font-sans">
        
        {/* HEADER */}
        <header className="bg-white border-b border-slate-200 px-8 py-6 sticky top-0 z-20 shadow-sm">
            <div className="max-w-7xl mx-auto w-full">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                    <div>
                        <h1 className="text-2xl font-bold text-slate-900 leading-none">Gestión de Flujo Pre-Quirúrgico</h1>
                        <p className="text-slate-500 text-sm mt-1">Supervisión de validaciones y desbloqueo de pacientes.</p>
                    </div>
                    <div className="flex items-center gap-3">
                         <div className="relative">
                            <span className="material-symbols-outlined absolute left-3 top-2.5 text-slate-400 text-lg">search</span>
                            <input 
                                type="text" 
                                placeholder="Filtrar pacientes..." 
                                className="pl-9 pr-4 py-2 rounded-lg border border-slate-300 bg-white text-sm focus:ring-2 focus:ring-primary focus:border-primary outline-none shadow-sm"
                                value={filterText}
                                onChange={(e) => setFilterText(e.target.value)}
                            />
                        </div>
                        <button 
                             onClick={() => navigate('/detail/new')}
                             className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-lg text-sm font-bold shadow-sm flex items-center gap-2 transition-colors"
                        >
                            <span className="material-symbols-outlined text-lg">add</span> Nueva Cirugía
                        </button>
                    </div>
                </div>

                {/* KPI SUMMARIES */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
                    <div className="bg-emerald-50 border border-emerald-100 p-3 rounded-lg flex items-center gap-3">
                         <div className="size-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                            <span className="material-symbols-outlined">event_available</span>
                         </div>
                         <div>
                             <p className="text-2xl font-black text-emerald-700 leading-none">{readyPatients.length}</p>
                             <p className="text-xs font-bold text-emerald-600 uppercase">Listos p/ Agendar</p>
                         </div>
                    </div>
                    <div className="bg-amber-50 border border-amber-100 p-3 rounded-lg flex items-center gap-3">
                         <div className="size-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center">
                            <span className="material-symbols-outlined">inventory_2</span>
                         </div>
                         <div>
                             <p className="text-2xl font-black text-amber-700 leading-none">{materialBlockers.length}</p>
                             <p className="text-xs font-bold text-amber-600 uppercase">Falta Material</p>
                         </div>
                    </div>
                    <div className="bg-blue-50 border border-blue-100 p-3 rounded-lg flex items-center gap-3">
                         <div className="size-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center">
                            <span className="material-symbols-outlined">clinical_notes</span>
                         </div>
                         <div>
                             <p className="text-2xl font-black text-blue-700 leading-none">{clinicalBlockers.length}</p>
                             <p className="text-xs font-bold text-blue-600 uppercase">Falta Clínico</p>
                         </div>
                    </div>
                     <div className="bg-white border border-slate-200 p-3 rounded-lg flex items-center gap-3">
                         <div className="size-10 rounded-full bg-slate-100 text-slate-500 flex items-center justify-center">
                            <span className="material-symbols-outlined">groups</span>
                         </div>
                         <div>
                             <p className="text-2xl font-black text-slate-700 leading-none">{patients.length}</p>
                             <p className="text-xs font-bold text-slate-500 uppercase">Total Activos</p>
                         </div>
                    </div>
                </div>
            </div>
        </header>

        {/* MAIN CONTENT GRID */}
        <div className="flex-1 p-8 max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* LEFT COLUMN: ACTIONABLE (READY) - Spans full width on mobile, 8 cols on desktop */}
            <div className="lg:col-span-12 flex flex-col gap-8">
                
                {/* SECTION: READY TO LAUNCH */}
                <section>
                    <div className="flex items-center gap-2 mb-4">
                        <span className="material-symbols-outlined text-emerald-500 text-xl">rocket_launch</span>
                        <h2 className="text-lg font-bold text-slate-900">Listos para Programar</h2>
                        <span className="bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded-full text-xs font-bold">{readyPatients.length}</span>
                        <div className="flex-1 border-b border-slate-200 ml-4"></div>
                    </div>
                    
                    {readyPatients.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                            {readyPatients.map(p => (
                                <div key={p.id} className="relative group">
                                     <PatientCard patient={p} />
                                     {/* Quick Schedule Button Overlay */}
                                     <div className="absolute inset-x-4 bottom-4 opacity-0 group-hover:opacity-100 transition-opacity flex justify-center">
                                         <button 
                                            onClick={(e) => { e.stopPropagation(); navigate('/calendar'); }}
                                            className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-2 px-4 rounded-lg shadow-lg flex items-center gap-2 transform translate-y-2 group-hover:translate-y-0 transition-transform"
                                         >
                                             <span className="material-symbols-outlined text-sm">calendar_add_on</span>
                                             Agendar Ahora
                                         </button>
                                     </div>
                                </div>
                            ))}
                        </div>
                    ) : (
                        <div className="bg-slate-100 border-2 border-dashed border-slate-200 rounded-xl p-8 text-center">
                            <p className="text-slate-400 font-medium">No hay pacientes listos para agendar en este momento.</p>
                        </div>
                    )}
                </section>

                {/* SECTION: BLOCKED PIPELINES */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    
                    {/* COL 1: Material Issues */}
                    <section className="bg-slate-100/50 rounded-xl p-4 border border-slate-200/60">
                         <div className="flex items-center gap-2 mb-4">
                            <span className="material-symbols-outlined text-amber-500">inventory_2</span>
                            <h2 className="text-base font-bold text-slate-700">Bloqueo: Falta Materiales</h2>
                            <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full text-xs font-bold">{materialBlockers.length}</span>
                        </div>
                        <div className="space-y-3">
                            {materialBlockers.map(p => (
                                <PatientCard key={p.id} patient={p} />
                            ))}
                            {materialBlockers.length === 0 && <p className="text-xs text-slate-400 italic">Todo despejado.</p>}
                        </div>
                    </section>

                    {/* COL 2: Clinical Issues */}
                    <section className="bg-slate-100/50 rounded-xl p-4 border border-slate-200/60">
                         <div className="flex items-center gap-2 mb-4">
                            <span className="material-symbols-outlined text-blue-500">cardiology</span>
                            <h2 className="text-base font-bold text-slate-700">Bloqueo: Faltan Estudios</h2>
                            <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full text-xs font-bold">{clinicalBlockers.length}</span>
                        </div>
                        <div className="space-y-3">
                            {clinicalBlockers.map(p => (
                                <PatientCard key={p.id} patient={p} />
                            ))}
                             {clinicalBlockers.length === 0 && <p className="text-xs text-slate-400 italic">Todo despejado.</p>}
                        </div>
                    </section>

                </div>

                {/* SECTION: NEW / INTAKE */}
                {newRequests.length > 0 && (
                     <section className="mt-4">
                        <div className="flex items-center gap-2 mb-4">
                            <span className="material-symbols-outlined text-slate-400">new_releases</span>
                            <h2 className="text-base font-bold text-slate-500">Solicitudes Recientes (Sin procesar)</h2>
                            <div className="flex-1 border-b border-slate-200 ml-4"></div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 opacity-75 hover:opacity-100 transition-opacity">
                             {newRequests.map(p => (
                                <PatientCard key={p.id} patient={p} minimal />
                            ))}
                        </div>
                    </section>
                )}

            </div>
        </div>
    </div>
  );
};

export default Kanban;