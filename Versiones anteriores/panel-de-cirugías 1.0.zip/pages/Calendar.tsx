import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// --- Types & Helpers ---
type ViewMode = 'month' | 'week' | 'day';

interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date; 
  color: string;
  icon?: string;
  completed?: boolean;
  orId: string; // Added OR ID to track room usage
}

interface PendingSurgery {
    id: string;
    name: string;
    proc: string;
    doctor: string;
    duration: number; // minutes
    color: string;
}

const MOCK_ORS = [
    { id: '1', name: 'Qx 1 (General)' },
    { id: '2', name: 'Qx 2 (Orto)' },
    { id: '3', name: 'Qx 3 (Amb)' },
];

// Mock Data matching "Ready for Surgery - No Date" column from Kanban
const PENDING_SURGERIES: PendingSurgery[] = [
      { id: '11.223.344', name: 'Carlos Ruiz', proc: 'Apendicectomía', doctor: 'Dr. Garcia', duration: 90, color: 'bg-blue-500' },
      { id: '99.888.777', name: 'Elena Vazquez', proc: 'Reparación LCA', doctor: 'Dra. Lopez', duration: 120, color: 'bg-blue-500' },
      { id: '87.654.321', name: 'Luis Torres', proc: 'Chequeo General', doctor: 'Dr. Fernandez', duration: 30, color: 'bg-blue-500' },
];

// Mock Data Generator
const generateMockEvents = (baseDate: Date): CalendarEvent[] => {
  const y = baseDate.getFullYear();
  const m = baseDate.getMonth();
  const d = baseDate.getDate();

  return [
    { id: '101', title: 'Cataratas', start: new Date(y, m, 2, 8, 0), end: new Date(y, m, 2, 9, 30), color: 'bg-slate-500', orId: '3' },
    { id: '102', title: 'Rodilla', start: new Date(y, m, 2, 11, 30), end: new Date(y, m, 2, 13, 0), color: 'bg-slate-500', orId: '2' },
    { id: '103', title: 'Apéndice', start: new Date(y, m, 5, 8, 30), end: new Date(y, m, 5, 10, 0), color: 'bg-emerald-500', icon: 'check_circle', completed: true, orId: '1' },
    // Conflict test: Same day
    { id: '111', title: 'Urgencia', start: new Date(y, m, d, 9, 0), end: new Date(y, m, d, 10, 30), color: 'bg-red-500', orId: '1' }, // Occupies Qx 1 from 9 to 10:30
    { id: '112', title: 'Revisión', start: new Date(y, m, d, 15, 0), end: new Date(y, m, d, 15, 30), color: 'bg-blue-500', orId: '2' },
  ];
};

const Calendar: React.FC = () => {
  const navigate = useNavigate();
  // State
  const [currentDate, setCurrentDate] = useState(new Date()); 
  const [view, setView] = useState<ViewMode>('month');
  
  // Data State
  const [events, setEvents] = useState<CalendarEvent[]>(() => generateMockEvents(new Date()));
  const [pendingSurgeries, setPendingSurgeries] = useState<PendingSurgery[]>(PENDING_SURGERIES);

  // Modal State
  const [showModal, setShowModal] = useState(false);
  const [modalDate, setModalDate] = useState<Date | null>(null);
  
  // Scheduling Logic State
  const [selectedPendingId, setSelectedPendingId] = useState<string | null>(null);
  const [selectedOrId, setSelectedOrId] = useState<string>('1');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string | null>(null);

  // -- Helpers --
  const selectedSurgery = useMemo(() => 
    pendingSurgeries.find(p => p.id === selectedPendingId), 
  [selectedPendingId, pendingSurgeries]);

  // Generate Time Slots (07:00 to 19:00, 30 min intervals)
  const generateTimeSlots = (date: Date, orId: string) => {
    const slots = [];
    const startHour = 7;
    const endHour = 19;

    // Filter events for this specific day and OR
    const dayEvents = events.filter(e => 
        e.start.getDate() === date.getDate() && 
        e.start.getMonth() === date.getMonth() &&
        e.orId === orId
    );

    for (let h = startHour; h < endHour; h++) {
        for (let m = 0; m < 60; m += 30) {
            const timeString = `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
            
            // Create a date object for this slot to compare
            const slotDate = new Date(date);
            slotDate.setHours(h, m, 0, 0);

            // Check if this slot overlaps with any existing event
            const isBusy = dayEvents.some(ev => {
                return slotDate >= ev.start && slotDate < ev.end;
            });

            slots.push({ time: timeString, busy: isBusy });
        }
    }
    return slots;
  };

  const availableSlots = useMemo(() => {
      if (!modalDate) return [];
      return generateTimeSlots(modalDate, selectedOrId);
  }, [modalDate, selectedOrId, events]);

  // -- Navigation Handlers --
  const handlePrev = () => {
    const newDate = new Date(currentDate);
    if (view === 'month') newDate.setMonth(newDate.getMonth() - 1);
    if (view === 'week') newDate.setDate(newDate.getDate() - 7);
    if (view === 'day') newDate.setDate(newDate.getDate() - 1);
    setCurrentDate(newDate);
  };

  const handleNext = () => {
    const newDate = new Date(currentDate);
    if (view === 'month') newDate.setMonth(newDate.getMonth() + 1);
    if (view === 'week') newDate.setDate(newDate.getDate() + 7);
    if (view === 'day') newDate.setDate(newDate.getDate() + 1);
    setCurrentDate(newDate);
  };

  const handleToday = () => setCurrentDate(new Date());

  // -- Modal Logic --
  const openScheduleModal = (date: Date, hour?: number) => {
      setModalDate(date);
      setSelectedOrId('1'); // Default OR
      setSelectedPendingId(null);
      
      // If a specific hour was clicked (Week/Day view), try to select it
      if (hour !== undefined) {
          const timeStr = `${hour.toString().padStart(2, '0')}:00`;
          setSelectedTimeSlot(timeStr);
      } else {
          setSelectedTimeSlot(null);
      }
      
      setShowModal(true);
  };

  const handleConfirmSchedule = () => {
      if (!modalDate || !selectedTimeSlot || !selectedPendingId) return;

      const surgery = pendingSurgeries.find(p => p.id === selectedPendingId);
      if (!surgery) return;

      const [h, m] = selectedTimeSlot.split(':').map(Number);
      const start = new Date(modalDate);
      start.setHours(h, m, 0, 0);
      
      const end = new Date(start);
      end.setMinutes(start.getMinutes() + surgery.duration);

      const newEvent: CalendarEvent = {
          id: `evt-${Date.now()}`,
          title: surgery.proc,
          start,
          end,
          color: surgery.color,
          orId: selectedOrId
      };

      setEvents([...events, newEvent]);
      setPendingSurgeries(prev => prev.filter(p => p.id !== surgery.id));
      setShowModal(false);
  };

  // -- Formatting Helpers --
  const getHeaderTitle = () => {
    const options: Intl.DateTimeFormatOptions = { month: 'long', year: 'numeric' };
    if (view === 'day') options.day = 'numeric';
    return new Intl.DateTimeFormat('es-ES', options).format(currentDate);
  };

  const isSameDate = (d1: Date, d2: Date) => 
    d1.getDate() === d2.getDate() && 
    d1.getMonth() === d2.getMonth() && 
    d1.getFullYear() === d2.getFullYear();

  const isFutureOrToday = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const target = new Date(date);
    target.setHours(0, 0, 0, 0);
    return target >= today;
  };

  // -- Views Components --

  // 1. Month View
  const MonthView = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    const firstDayOfMonth = new Date(year, month, 1).getDay(); // 0 = Sun
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    
    // Padding for start of month
    const paddingDays = Array.from({ length: firstDayOfMonth }, (_, i) => i);
    const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);

    const weekDays = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

    return (
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 h-full flex flex-col min-h-[600px]">
        <div className="grid grid-cols-7 border-b border-slate-200">
          {weekDays.map((d) => (
            <div key={d} className="py-3 text-center text-sm font-semibold text-slate-500 uppercase tracking-wider">
              {d}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 grid-rows-5 flex-1">
          {paddingDays.map(i => (
             <div key={`pad-${i}`} className="border-b border-r border-slate-100 p-2 bg-slate-50/50"></div>
          ))}
          {days.map((d) => {
             const dayDate = new Date(year, month, d);
             const isToday = isSameDate(dayDate, new Date());
             const dayEvents = events.filter(e => isSameDate(e.start, dayDate));
             const canAdd = isFutureOrToday(dayDate);

             return (
              <div key={d} className="border-b border-r border-slate-100 p-2 hover:bg-slate-50 transition-colors relative group/cell min-h-[100px]">
                <div className="flex justify-between items-start">
                  <span className={`text-sm font-bold ${isToday ? 'flex size-7 items-center justify-center rounded-full bg-primary text-white shadow-md' : 'text-slate-900'}`}>
                    {d}
                  </span>
                  {isToday && <span className="text-[10px] font-bold text-primary uppercase mr-1">Hoy</span>}
                </div>
                <div className="mt-2 flex flex-col gap-1">
                    {dayEvents.map(ev => (
                         <button 
                            key={ev.id}
                            onClick={(e) => { e.stopPropagation(); navigate(`/detail/${ev.id}`); }}
                            className={`w-full text-left ${ev.color} text-white px-2 py-1 rounded text-xs font-medium truncate shadow-sm flex items-center justify-between hover:opacity-90 transition-opacity`}
                        >
                            <span>
                                {ev.start.getHours().toString().padStart(2,'0')}:{ev.start.getMinutes().toString().padStart(2,'0')} • {ev.title}
                            </span>
                            {ev.icon && <span className="material-symbols-outlined text-[10px]">{ev.icon}</span>}
                        </button>
                    ))}
                </div>
                 {/* Hover Add Button */}
                 {canAdd && (
                    <button 
                        onClick={(e) => { e.stopPropagation(); openScheduleModal(dayDate); }}
                        className="absolute top-2 right-2 opacity-0 group-hover/cell:opacity-100 p-1 text-primary hover:bg-blue-50 rounded transition-opacity"
                        title="Agendar Cirugía"
                    >
                        <span className="material-symbols-outlined text-[16px]">add</span>
                    </button>
                 )}
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  // 2. Week View
  const WeekView = () => {
    const startOfWeek = new Date(currentDate);
    const day = currentDate.getDay();
    const diff = currentDate.getDate() - day; 
    startOfWeek.setDate(diff);

    const weekDates = Array.from({ length: 7 }, (_, i) => {
        const d = new Date(startOfWeek);
        d.setDate(d.getDate() + i);
        return d;
    });

    const hours = Array.from({ length: 13 }, (_, i) => i + 7); // 07:00 to 19:00

    return (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 h-full flex flex-col overflow-hidden">
            {/* Header */}
            <div className="grid grid-cols-8 border-b border-slate-200 divide-x divide-slate-100 bg-slate-50">
                <div className="p-3 text-center text-xs font-bold text-slate-400 uppercase pt-4">Hora</div>
                {weekDates.map((date, i) => {
                    const isToday = isSameDate(date, new Date());
                    return (
                        <div key={i} className={`p-3 text-center ${isToday ? 'bg-primary/5' : ''}`}>
                            <div className={`text-xs font-semibold uppercase ${isToday ? 'text-primary' : 'text-slate-500'}`}>
                                {date.toLocaleDateString('es-ES', { weekday: 'short' })}
                            </div>
                            <div className={`text-lg font-bold ${isToday ? 'text-primary' : 'text-slate-900'}`}>
                                {date.getDate()}
                            </div>
                        </div>
                    );
                })}
            </div>
            {/* Grid */}
            <div className="flex-1 overflow-y-auto">
                 <div className="grid grid-cols-8 divide-x divide-slate-100">
                    <div className="bg-slate-50/50">
                        {hours.map(h => (
                            <div key={h} className="h-20 border-b border-slate-100 text-right pr-2 pt-2 text-xs text-slate-400 font-medium relative">
                                {h}:00
                            </div>
                        ))}
                    </div>
                    {weekDates.map((date, i) => {
                         const canAdd = isFutureOrToday(date);
                         return (
                             <div key={i} className="relative group/col">
                                {hours.map(h => (
                                    <div 
                                        key={h} 
                                        onClick={() => canAdd && openScheduleModal(date, h)}
                                        className={`h-20 border-b border-slate-100 relative group/cell ${canAdd ? 'hover:bg-slate-50/80 cursor-pointer' : ''}`}
                                    >
                                        {canAdd && (
                                            <span className="absolute inset-0 flex items-center justify-center opacity-0 group-hover/cell:opacity-100 text-slate-300">
                                                <span className="material-symbols-outlined text-sm">add</span>
                                            </span>
                                        )}
                                    </div>
                                ))}
                                {events
                                    .filter(e => isSameDate(e.start, date))
                                    .map(ev => {
                                        const startHour = ev.start.getHours();
                                        const startMin = ev.start.getMinutes();
                                        const durationMin = (ev.end.getTime() - ev.start.getTime()) / (1000 * 60);
                                        const topOffset = ((startHour - 7) * 80) + ((startMin / 60) * 80); 
                                        const height = (durationMin / 60) * 80;
                                        if (startHour < 7 || startHour > 19) return null;
                                        return (
                                            <button 
                                                key={ev.id}
                                                onClick={(e) => { e.stopPropagation(); navigate(`/detail/${ev.id}`); }}
                                                style={{ top: `${topOffset}px`, height: `${height}px` }}
                                                className={`absolute left-1 right-1 rounded px-2 py-1 text-xs font-bold text-white shadow-sm z-10 flex flex-col justify-start items-start overflow-hidden hover:brightness-110 transition-all ${ev.color}`}
                                            >
                                                <span className="truncate w-full text-left">{ev.title}</span>
                                                <span className="opacity-80 text-[10px]">{startHour}:{startMin.toString().padStart(2,'0')}</span>
                                            </button>
                                        );
                                    })
                                }
                             </div>
                         );
                    })}
                 </div>
            </div>
        </div>
    );
  };

  // 3. Day View
  const DayView = () => {
    const hours = Array.from({ length: 13 }, (_, i) => i + 7);
    const canAdd = isFutureOrToday(currentDate);

    return (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 h-full flex flex-col overflow-hidden max-w-4xl mx-auto w-full">
            <div className="border-b border-slate-200 p-4 bg-slate-50 flex justify-center">
                 <div className="text-center">
                    <div className="text-sm font-semibold uppercase text-primary">
                        {currentDate.toLocaleDateString('es-ES', { weekday: 'long' })}
                    </div>
                    <div className="text-3xl font-black text-slate-900">
                        {currentDate.getDate()}
                    </div>
                 </div>
            </div>
             <div className="flex-1 overflow-y-auto">
                 <div className="grid grid-cols-[80px_1fr] divide-x divide-slate-100">
                     <div className="bg-slate-50/50">
                        {hours.map(h => (
                            <div key={h} className="h-24 border-b border-slate-100 text-right pr-4 pt-2 text-sm text-slate-400 font-bold">
                                {h}:00
                            </div>
                        ))}
                    </div>
                    <div className="relative bg-white">
                        {hours.map(h => (
                            <div key={h} className="h-24 border-b border-slate-100 flex flex-col justify-center px-4 hover:bg-slate-50 transition-colors group">
                                {canAdd && (
                                    <button 
                                        onClick={() => openScheduleModal(currentDate, h)}
                                        className="opacity-0 group-hover:opacity-100 text-xs text-slate-400 font-bold flex items-center gap-1 hover:text-primary transition-colors"
                                    >
                                        <span className="material-symbols-outlined text-base">add</span> Agendar
                                    </button>
                                )}
                            </div>
                        ))}
                        {events
                            .filter(e => isSameDate(e.start, currentDate))
                            .map(ev => {
                                const startHour = ev.start.getHours();
                                const startMin = ev.start.getMinutes();
                                const durationMin = (ev.end.getTime() - ev.start.getTime()) / (1000 * 60);
                                const pxPerHour = 96;
                                const topOffset = ((startHour - 7) * pxPerHour) + ((startMin / 60) * pxPerHour); 
                                const height = (durationMin / 60) * pxPerHour;
                                if (startHour < 7 || startHour > 19) return null;
                                return (
                                    <button 
                                        key={ev.id}
                                        onClick={(e) => { e.stopPropagation(); navigate(`/detail/${ev.id}`); }}
                                        style={{ top: `${topOffset}px`, height: `${height}px` }}
                                        className={`absolute left-2 right-4 rounded-lg px-4 py-2 text-sm font-medium text-white shadow-md z-10 flex items-center justify-between hover:scale-[1.01] transition-all border-l-4 border-black/20 ${ev.color}`}
                                    >
                                        <div className="flex flex-col items-start">
                                            <span className="font-bold text-lg">{ev.title}</span>
                                            <span className="opacity-90">{startHour}:{startMin.toString().padStart(2,'0')} - {ev.end.getHours()}:{ev.end.getMinutes().toString().padStart(2,'0')} (Qx {ev.orId})</span>
                                        </div>
                                        {ev.icon && <span className="material-symbols-outlined text-2xl bg-white/20 p-1 rounded-full">{ev.icon}</span>}
                                    </button>
                                );
                            })
                        }
                    </div>
                 </div>
             </div>
        </div>
    );
  };

  return (
    <div className="flex-1 flex flex-col min-w-0 bg-background overflow-hidden h-full relative">
      {/* Calendar Header */}
      <div className="px-6 py-4 flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 bg-white sticky top-0 z-10">
        <div className="flex items-center gap-4">
          <h1 className="text-slate-900 text-2xl font-black leading-tight tracking-tight capitalize min-w-[200px]">
            {getHeaderTitle()}
          </h1>
          <div className="flex items-center rounded-lg bg-slate-100 p-0.5">
            <button 
                onClick={handlePrev}
                className="p-1 hover:bg-white rounded-md shadow-sm transition-all text-slate-900"
            >
              <span className="material-symbols-outlined text-[20px]">chevron_left</span>
            </button>
            <button 
                onClick={handleNext}
                className="p-1 hover:bg-white rounded-md shadow-sm transition-all text-slate-900"
            >
              <span className="material-symbols-outlined text-[20px]">chevron_right</span>
            </button>
          </div>
          <button 
            onClick={handleToday}
            className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-sm font-bold text-slate-900 hover:bg-slate-50 transition-colors"
          >
            Hoy
          </button>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex h-9 items-center rounded-lg bg-slate-100 p-1">
            <button 
                onClick={() => setView('month')}
                className={`flex items-center justify-center px-3 py-1 rounded-md text-xs font-bold transition-all ${view === 'month' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-900'}`}
            >
                Mes
            </button>
            <button 
                onClick={() => setView('week')}
                className={`flex items-center justify-center px-3 py-1 rounded-md text-xs font-bold transition-all ${view === 'week' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-900'}`}
            >
                Semana
            </button>
            <button 
                onClick={() => setView('day')}
                className={`flex items-center justify-center px-3 py-1 rounded-md text-xs font-bold transition-all ${view === 'day' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500 hover:text-slate-900'}`}
            >
                Día
            </button>
          </div>
        </div>
      </div>

      {/* Calendar Grid Container */}
      <div className="flex-1 overflow-y-auto p-6">
          {view === 'month' && <MonthView />}
          {view === 'week' && <WeekView />}
          {view === 'day' && <DayView />}
      </div>

      {/* SMART SCHEDULING MODAL */}
      {showModal && modalDate && (
         <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-sm p-4 animate-fadeIn">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl flex flex-col max-h-[90vh]">
                <div className="p-5 border-b border-slate-200 bg-slate-50 rounded-t-xl flex justify-between items-center">
                    <div>
                        <h3 className="text-lg font-bold text-slate-900">Agendar Cirugía</h3>
                        <p className="text-xs text-slate-500 font-medium capitalize">
                            {modalDate.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long' })}
                        </p>
                    </div>
                    <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                        <span className="material-symbols-outlined">close</span>
                    </button>
                </div>
                
                <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
                    
                    {/* LEFT COL: SELECT PATIENT */}
                    <div className="w-full md:w-1/3 border-r border-slate-200 flex flex-col bg-slate-50">
                        <div className="p-4 border-b border-slate-200">
                            <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-1">1. Seleccionar Paciente</h4>
                            <p className="text-[10px] text-slate-400">Desde lista de espera (Kanban)</p>
                        </div>
                        <div className="flex-1 overflow-y-auto p-4 space-y-3">
                             {pendingSurgeries.map(surgery => (
                                <div 
                                    key={surgery.id} 
                                    onClick={() => setSelectedPendingId(surgery.id)}
                                    className={`cursor-pointer border rounded-lg p-3 transition-all flex flex-col gap-1 ${
                                        selectedPendingId === surgery.id 
                                        ? 'bg-white border-primary ring-2 ring-primary/20 shadow-md' 
                                        : 'bg-white border-slate-200 hover:border-slate-300 hover:shadow-sm'
                                    }`}
                                >
                                    <div className="flex justify-between items-start">
                                        <p className="font-bold text-slate-900 text-sm">{surgery.name}</p>
                                        <span className="text-[10px] bg-slate-100 px-1.5 py-0.5 rounded font-mono text-slate-600">{surgery.duration}m</span>
                                    </div>
                                    <p className="text-xs text-slate-500">{surgery.proc}</p>
                                    <p className="text-[10px] text-slate-400 flex items-center gap-1">
                                        <span className="material-symbols-outlined text-[10px]">person</span>
                                        {surgery.doctor}
                                    </p>
                                </div>
                            ))}
                            {pendingSurgeries.length === 0 && (
                                <div className="text-center py-8 opacity-50">
                                    <span className="material-symbols-outlined text-3xl mb-1">assignment_turned_in</span>
                                    <p className="text-xs">No hay pendientes.</p>
                                </div>
                            )}
                            <button 
                                onClick={() => navigate('/detail/new')}
                                className="w-full py-2 border border-dashed border-slate-300 text-slate-500 rounded hover:border-primary hover:text-primary transition-colors text-xs font-bold flex items-center justify-center gap-1"
                            >
                                <span className="material-symbols-outlined text-sm">add</span> Nueva Solicitud
                            </button>
                        </div>
                    </div>

                    {/* RIGHT COL: SELECT OR & TIME */}
                    <div className="w-full md:w-2/3 flex flex-col bg-white">
                        <div className="p-4 border-b border-slate-200">
                             <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">2. Seleccionar Quirófano y Hora</h4>
                             
                             {/* OR Tabs */}
                             <div className="flex p-1 bg-slate-100 rounded-lg">
                                 {MOCK_ORS.map(or => (
                                     <button
                                        key={or.id}
                                        onClick={() => setSelectedOrId(or.id)}
                                        className={`flex-1 py-1.5 text-xs font-bold rounded-md transition-all ${
                                            selectedOrId === or.id 
                                            ? 'bg-white text-slate-900 shadow-sm' 
                                            : 'text-slate-500 hover:text-slate-700'
                                        }`}
                                     >
                                         {or.name}
                                     </button>
                                 ))}
                             </div>
                        </div>

                        <div className="flex-1 overflow-y-auto p-6">
                            {selectedPendingId ? (
                                <>
                                    <div className="mb-4 flex items-center justify-between">
                                        <span className="text-xs font-bold text-slate-400 uppercase">Horarios Disponibles</span>
                                        <div className="flex items-center gap-3 text-[10px]">
                                            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-emerald-100 border border-emerald-300"></span> Libre</span>
                                            <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-slate-100 border border-slate-200"></span> Ocupado</span>
                                        </div>
                                    </div>
                                    
                                    <div className="grid grid-cols-4 gap-3">
                                        {availableSlots.map((slot, idx) => (
                                            <button
                                                key={idx}
                                                disabled={slot.busy}
                                                onClick={() => setSelectedTimeSlot(slot.time)}
                                                className={`py-2 px-1 rounded border text-sm font-medium transition-all ${
                                                    slot.busy 
                                                    ? 'bg-slate-50 text-slate-300 border-slate-100 cursor-not-allowed decoration-slate-300'
                                                    : selectedTimeSlot === slot.time
                                                        ? 'bg-emerald-500 text-white border-emerald-600 shadow-md transform scale-105'
                                                        : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-400 hover:text-emerald-600'
                                                }`}
                                            >
                                                {slot.time}
                                            </button>
                                        ))}
                                    </div>
                                    
                                    {selectedTimeSlot && (
                                        <div className="mt-6 p-3 bg-blue-50 border border-blue-100 rounded-lg text-xs text-blue-800 flex items-start gap-2">
                                            <span className="material-symbols-outlined text-sm">info</span>
                                            <p>
                                                Se agendará de <strong>{selectedTimeSlot}</strong> a <strong>
                                                    {(() => {
                                                        const [h,m] = selectedTimeSlot.split(':').map(Number);
                                                        const end = new Date(); 
                                                        end.setHours(h, m + (selectedSurgery?.duration || 0));
                                                        return `${end.getHours().toString().padStart(2,'0')}:${end.getMinutes().toString().padStart(2,'0')}`;
                                                    })()}
                                                </strong> en <strong>{MOCK_ORS.find(o => o.id === selectedOrId)?.name}</strong>.
                                            </p>
                                        </div>
                                    )}
                                </>
                            ) : (
                                <div className="h-full flex flex-col items-center justify-center text-slate-400 opacity-60">
                                    <span className="material-symbols-outlined text-4xl mb-2">arrow_back</span>
                                    <p className="text-sm">Seleccione un paciente primero</p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Footer Actions */}
                <div className="p-4 border-t border-slate-200 bg-slate-50 rounded-b-xl flex justify-end gap-3">
                    <button 
                        onClick={() => setShowModal(false)}
                        className="px-4 py-2 text-slate-600 hover:bg-white hover:shadow-sm rounded-lg font-bold text-sm border border-transparent hover:border-slate-200 transition-all"
                    >
                        Cancelar
                    </button>
                    <button 
                        disabled={!selectedPendingId || !selectedTimeSlot}
                        onClick={handleConfirmSchedule}
                        className="px-6 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg font-bold text-sm shadow-sm transition-all"
                    >
                        Confirmar Agendamiento
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default Calendar;