import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';

const Sidebar: React.FC = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleSidebar = () => setIsCollapsed(!isCollapsed);

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors relative group ${
      isActive
        ? 'bg-primary/10 text-primary'
        : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-400'
    } ${isCollapsed ? 'justify-center' : ''}`;

  const iconClass = ({ isActive }: { isActive: boolean }) =>
    `material-symbols-outlined flex-shrink-0 transition-all ${isActive ? 'filled' : ''} ${isCollapsed ? 'text-2xl' : ''}`;

  return (
    <aside 
      className={`
        flex-shrink-0 border-r border-slate-200 bg-white flex flex-col h-screen hidden md:flex z-20 relative transition-all duration-300 ease-in-out
        ${isCollapsed ? 'w-20' : 'w-64'}
      `}
    >
      {/* Toggle Button */}
      <button 
        onClick={toggleSidebar}
        className="absolute -right-3 top-9 bg-white border border-slate-200 text-slate-500 rounded-full p-1 shadow-sm hover:text-primary hover:border-primary transition-colors z-50 flex items-center justify-center size-6"
      >
        <span className="material-symbols-outlined text-sm font-bold">
          {isCollapsed ? 'chevron_right' : 'chevron_left'}
        </span>
      </button>

      <div className="h-full flex flex-col justify-between p-4 overflow-hidden">
        <div className="flex flex-col gap-4">
          {/* Brand */}
          <div className={`flex items-center px-2 py-2 transition-all ${isCollapsed ? 'justify-center gap-0' : 'gap-3'}`}>
            <div className="bg-primary/10 rounded-lg p-2 flex items-center justify-center text-primary flex-shrink-0">
              <span className="material-symbols-outlined text-2xl">medical_services</span>
            </div>
            
            {/* Brand Text - Fade out transition */}
            <div className={`flex flex-col overflow-hidden transition-all duration-300 ${isCollapsed ? 'w-0 opacity-0 ml-0' : 'w-auto opacity-100 ml-3'}`}>
              <h1 className="text-slate-900 text-base font-bold leading-normal whitespace-nowrap">ITEO</h1>
              <p className="text-slate-500 text-xs font-normal leading-normal whitespace-nowrap">Coordinación</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="flex flex-col gap-1 mt-4">
            <NavLink to="/" className={linkClass}>
              {({ isActive }) => (
                <>
                  <span className={iconClass({ isActive })} title={isCollapsed ? "Tablero" : ""}>dashboard</span>
                  {!isCollapsed && <p className="text-sm font-medium leading-normal whitespace-nowrap animate-fadeIn">Tablero</p>}
                </>
              )}
            </NavLink>
            
            <NavLink to="/alerts" className={linkClass}>
              {({ isActive }) => (
                <>
                  <div className="relative flex items-center justify-center">
                    <span className={`${iconClass({ isActive })} ${!isActive ? 'text-red-500' : ''}`} title={isCollapsed ? "Centro de Alertas" : ""}>notifications_active</span>
                    {/* Collapsed Badge (Dot) */}
                    {isCollapsed && !isActive && (
                       <span className="absolute top-0 right-0 -mt-1 -mr-1 size-2.5 bg-red-500 rounded-full border-2 border-white"></span>
                    )}
                  </div>
                  
                  {!isCollapsed && (
                    <div className="flex justify-between items-center w-full animate-fadeIn overflow-hidden">
                      <p className="text-sm font-medium leading-normal whitespace-nowrap">Centro de Alertas</p>
                      {!isActive && <span className="bg-red-500 text-white text-[10px] px-1.5 rounded-full font-bold ml-2">3</span>}
                    </div>
                  )}
                </>
              )}
            </NavLink>

            <NavLink to="/calendar" className={linkClass}>
              {({ isActive }) => (
                <>
                  <span className={iconClass({ isActive })} title={isCollapsed ? "Calendario" : ""}>calendar_today</span>
                  {!isCollapsed && <p className="text-sm font-medium leading-normal whitespace-nowrap animate-fadeIn">Calendario</p>}
                </>
              )}
            </NavLink>
            <NavLink to="/kanban" className={linkClass}>
              {({ isActive }) => (
                <>
                  <span className={iconClass({ isActive })} title={isCollapsed ? "Planificación" : ""}>view_kanban</span>
                  {!isCollapsed && <p className="text-sm font-medium leading-normal whitespace-nowrap animate-fadeIn">Planificación</p>}
                </>
              )}
            </NavLink>
             <NavLink to="/surgeries" className={linkClass}>
              {({ isActive }) => (
                <>
                  <span className={iconClass({ isActive })} title={isCollapsed ? "Listado General" : ""}>table_rows</span>
                  {!isCollapsed && <p className="text-sm font-medium leading-normal whitespace-nowrap animate-fadeIn">Listado General</p>}
                </>
              )}
            </NavLink>
             <NavLink to="/monitor" className={linkClass}>
              {({ isActive }) => (
                <>
                  <span className={iconClass({ isActive })} title={isCollapsed ? "Monitor en Vivo" : ""}>monitor_heart</span>
                  {!isCollapsed && <p className="text-sm font-medium leading-normal whitespace-nowrap animate-fadeIn">Monitor en Vivo</p>}
                </>
              )}
            </NavLink>
             <NavLink to="/results" className={linkClass}>
              {({ isActive }) => (
                <>
                  <span className={iconClass({ isActive })} title={isCollapsed ? "Resultados" : ""}>analytics</span>
                  {!isCollapsed && <p className="text-sm font-medium leading-normal whitespace-nowrap animate-fadeIn">Resultados</p>}
                </>
              )}
            </NavLink>
             <NavLink to="/audit" className={linkClass}>
              {({ isActive }) => (
                <>
                  <span className={iconClass({ isActive })} title={isCollapsed ? "Auditoría" : ""}>history_edu</span>
                  {!isCollapsed && <p className="text-sm font-medium leading-normal whitespace-nowrap animate-fadeIn">Auditoría</p>}
                </>
              )}
            </NavLink>
             <NavLink to="/settings" className={linkClass}>
              {({ isActive }) => (
                <>
                  <span className={iconClass({ isActive })} title={isCollapsed ? "Configuración" : ""}>settings</span>
                  {!isCollapsed && <p className="text-sm font-medium leading-normal whitespace-nowrap animate-fadeIn">Configuración</p>}
                </>
              )}
            </NavLink>
          </nav>
        </div>

        {/* Bottom User Profile */}
        <div className={`flex items-center px-3 py-3 rounded-lg border border-slate-200 mt-auto cursor-pointer hover:bg-slate-50 transition-all ${isCollapsed ? 'justify-center border-transparent hover:border-slate-200' : 'gap-3'}`}>
          <img 
            src="https://picsum.photos/100/100" 
            alt="User" 
            className="h-10 w-10 rounded-full object-cover flex-shrink-0"
          />
          <div className={`flex flex-col overflow-hidden transition-all duration-300 ${isCollapsed ? 'w-0 opacity-0 ml-0' : 'w-auto opacity-100'}`}>
            <p className="text-sm font-medium truncate whitespace-nowrap">Dra. Sarah C.</p>
            <p className="text-xs text-slate-500 truncate whitespace-nowrap">Cirujano Jefe</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;